import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.StdRandom;
import java.lang.Math;

public class PercolationStats {
    private Percolation trail;
    private double[] trialData;
    private double trailMean;
    private double trailDev;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException();
        }
        this.trialData = new double[trials];
        this.trailMean = 0;
        this.trailDev = 0;
        int trialTimes = 0;

        while (trialTimes < trials) {
            this.trail = new Percolation(n);
            while (!this.trail.percolates()) {
                this.trail.open(StdRandom.uniformInt(0, n + 1), StdRandom.uniformInt(0, n + 1));
            }
            this.trialData[trialTimes] = (double) this.trail.numberOfOpenSites() / (double) (n * n);
            trialTimes++;
        }
    }

    // sample mean of percolation threshold
    public double mean() {
        this.trailMean = StdStats.mean(trialData);
        return this.trailMean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        this.trailDev = StdStats.stddev(trialData);
        return this.trailDev;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return this.trailMean - 1.96 * Math.sqrt(this.trailDev) / Math.sqrt(this.trialData.length);
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return this.trailMean + 1.96 * Math.sqrt(this.trailDev) / Math.sqrt(this.trialData.length);
    }

    // test client
    public static void main(String[] args) {

    }
}
